## [0.2.3] - 2026-07-23

### Changed
- Chart update

