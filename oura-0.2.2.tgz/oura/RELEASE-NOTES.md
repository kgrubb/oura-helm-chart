## [0.2.2] - 2026-07-23

### Changed
- Chart update

