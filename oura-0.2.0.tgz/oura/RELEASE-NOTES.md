## [0.2.0] - 2026-07-23

### Changed
- Chart update

