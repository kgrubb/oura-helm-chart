## [0.2.4] - 2026-07-23

### Changed
- Chart update

