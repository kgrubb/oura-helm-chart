## [0.1.2] - 2026-07-23

### Changed
- Chart update

