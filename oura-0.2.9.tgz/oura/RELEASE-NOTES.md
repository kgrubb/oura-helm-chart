## [0.2.9] - 2026-07-23

### Fixed
- polish Oura dashboard UX and score radar on readiness day

