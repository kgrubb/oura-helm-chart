## [0.2.7] - 2026-07-23

### Fixed
- make Symptom Radar conservative (v2) and clarify dashboard.

