## [0.2.5] - 2026-07-23

### Changed
- Chart update

