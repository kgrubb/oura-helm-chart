## [0.2.1] - 2026-07-23

### Changed
- Chart update

