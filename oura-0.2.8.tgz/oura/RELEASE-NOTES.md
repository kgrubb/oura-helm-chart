## [0.2.8] - 2026-07-23

### Fixed
- calibrate Symptom Radar v3 and rename to no signs

