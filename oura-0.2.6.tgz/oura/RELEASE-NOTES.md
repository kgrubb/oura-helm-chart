## [0.2.6] - 2026-07-23

### Changed
- backfill real changelog entries for all chart releases.

