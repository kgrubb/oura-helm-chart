## [0.2.10] - 2026-07-24

### Fixed
- default collector schedule to every 15 minutes

